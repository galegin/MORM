﻿using MORM.Apresentacao.Commands;
using MORM.Apresentacao.Servico.Commands.Tela;
using MORM.Repositorio.Uow;

namespace MORM.Apresentacao.Servico.Commands
{
    public class MainCommandService : IMainCommand
    {
        private readonly IAbstractUnityOfWork _uow;

        public MainCommandService(IAbstractUnityOfWork uow)
        {
            _uow = uow;
        }

        public AbstractCommand GetCommand<TEntrada>(CommandTipo tipo)
        {
            switch (tipo)
            {
                case CommandTipo.Alterar:
                    return new AlterarTela<TEntrada>(_uow);
                case CommandTipo.Consultar:
                    return new ConsultarTela<TEntrada>(_uow);
                case CommandTipo.Excluir:
                    return new ExcluirTela<TEntrada>(_uow);
                case CommandTipo.Exportar:
                    return new ExportarTela<TEntrada>(_uow);
                case CommandTipo.Importar:
                    return new ImportarTela<TEntrada>(_uow);
                case CommandTipo.Imprimir:
                    return new ImprimirTela<TEntrada>(_uow);
                case CommandTipo.Incluir:
                    return new IncluirTela<TEntrada>(_uow);
                case CommandTipo.Limpar:
                    return new LimparTela<TEntrada>(_uow);
                case CommandTipo.Salvar:
                    return new AlterarTela<TEntrada>(_uow);
            }

            return null;
        }

        public AbstractCommand GetCommandLista<TEntrada, TRetorno>(CommandTipo tipo)
        {
            switch (tipo)
            {
                case CommandTipo.Listar:
                    return new ListarTela<TEntrada, TRetorno>(_uow);
            }

            return null;
        }
    }
}