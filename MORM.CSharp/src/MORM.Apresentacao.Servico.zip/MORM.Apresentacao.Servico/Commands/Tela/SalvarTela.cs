﻿using MORM.Apresentacao.Connectors;
using MORM.Apresentacao.ViewsModel;
using MORM.Repositorio.Uow;

namespace MORM.Apresentacao.Servico.Commands.Tela
{
    public class SalvarTela<TEntrada> : AbstractCommandService<TEntrada>
    {
        public SalvarTela(IAbstractUnityOfWork uow) : base(uow)
        {
        }

        public override void Execute(object parameter)
        {
            var vm = parameter as AbstractViewModel<TEntrada>;
            var connector = new AbstractSalvarConnector<TEntrada>();
            connector.Executar(vm.Model);
        }
    }
}