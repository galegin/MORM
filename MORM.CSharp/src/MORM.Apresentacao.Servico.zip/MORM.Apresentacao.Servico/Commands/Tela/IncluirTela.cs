﻿using MORM.Apresentacao.ViewsModel;
using MORM.Repositorio.Uow;

namespace MORM.Apresentacao.Servico.Commands.Tela
{
    public class IncluirTela<TEntrada> : AbstractCommandService<TEntrada>
    {
        public IncluirTela(IAbstractUnityOfWork uow) : base(uow)
        {
        }

        public override void Execute(object parameter)
        {
            var vm = parameter as AbstractViewModel<TEntrada>;
            _service.Incluir(vm.Model);
        }
    }
}