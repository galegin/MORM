﻿using MORM.Apresentacao.ViewsModel;
using MORM.Dominio.Extensoes;
using MORM.Repositorio.Uow;

namespace MORM.Apresentacao.Servico.Commands.Tela
{
    public class LimparTela<TEntrada> : AbstractCommandService<TEntrada>
    {
        public LimparTela(IAbstractUnityOfWork uow) : base(uow)
        {
        }

        public override void Execute(object parameter)
        {
            var vm = parameter as AbstractViewModel<TEntrada>;
            vm.Model.ClearInstancePropOrFieldAll();
        }
    }
}