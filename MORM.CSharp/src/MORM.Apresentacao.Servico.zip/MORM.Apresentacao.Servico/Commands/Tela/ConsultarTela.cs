﻿using MORM.Apresentacao.ViewsModel;
using MORM.Dominio.Extensoes;
using MORM.Repositorio.Uow;

namespace MORM.Apresentacao.Servico.Commands.Tela
{
    public class ConsultarTela<TEntrada> : AbstractCommandService<TEntrada>
    {
        public ConsultarTela(IAbstractUnityOfWork uow) : base(uow)
        {
        }

        public override void Execute(object parameter)
        {
            var vm = parameter as AbstractViewModel<TEntrada>;
            var retorno = _service.Consultar(vm.Model);
            vm.Model.CloneInstancePropOrFieldAll(retorno);
        }
    }
}