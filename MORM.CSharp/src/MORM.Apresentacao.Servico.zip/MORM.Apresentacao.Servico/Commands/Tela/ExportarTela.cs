﻿using MORM.Apresentacao.ViewsModel;
using MORM.Repositorio.Uow;

namespace MORM.Apresentacao.Servico.Commands.Tela
{
    public class ExportarTela<TEntrada> : AbstractCommandService<TEntrada>
    {
        public ExportarTela(IAbstractUnityOfWork uow) : base(uow)
        {
        }

        public override void Execute(object parameter)
        {
            var vm = parameter as AbstractViewModel<TEntrada>;
            //_service.Exportar(vm.Model);
        }
    }
}