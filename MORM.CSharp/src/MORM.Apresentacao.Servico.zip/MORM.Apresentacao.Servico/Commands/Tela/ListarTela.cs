﻿using MORM.Apresentacao.ViewsModel;
using MORM.Repositorio.Uow;
using System.Collections.Generic;

namespace MORM.Apresentacao.Servico.Commands.Tela
{
    public class ListarTela<TEntrada, TRetorno> : AbstractCommandService<TEntrada>
    {
        public ListarTela(IAbstractUnityOfWork uow) : base(uow)
        {
        }

        public override void Execute(object parameter)
        {
            var vm = parameter as AbstractViewModel<TEntrada, TRetorno>;
            vm.Lista = _service.Listar(vm.Filtro) as List<TRetorno>;
        }
    }
}