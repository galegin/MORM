﻿using MORM.Apresentacao.ViewsModel;
using MORM.Repositorio.Uow;

namespace MORM.Apresentacao.Servico.Commands.Tela
{
    public class ImprimirTela<TEntrada> : AbstractCommandService<TEntrada>
    {
        public ImprimirTela(IAbstractUnityOfWork uow) : base(uow)
        {
        }

        public override void Execute(object parameter)
        {
            var vm = parameter as AbstractViewModel<TEntrada>;
            //_service.Imprimir(vm.Model);
        }
    }
}