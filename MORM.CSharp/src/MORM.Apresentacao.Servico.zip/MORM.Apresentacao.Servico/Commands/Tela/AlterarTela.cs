﻿using MORM.Apresentacao.Controls.ViewsModel;
using MORM.Repositorio.Uow;

namespace MORM.Apresentacao.Servico.Commands.Tela
{
    public class AlterarTela<TEntrada> : AbstractCommandService<TEntrada>
    {
        public AlterarTela(IAbstractUnityOfWork uow) : base(uow)
        {
        }

        public override void Execute(object parameter)
        {
            var vm = parameter as AbstractOpcaoViewModel<TEntrada>;
            _service.Alterar(vm.Model);
        }
    }
}