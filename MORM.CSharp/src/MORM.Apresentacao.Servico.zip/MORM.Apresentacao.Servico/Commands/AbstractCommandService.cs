﻿using MORM.Apresentacao.Commands;
using MORM.Repositorio.Uow;
using MORM.Servico.Interfaces;
using MORM.Servico.Services;

namespace MORM.Apresentacao.Servico.Commands
{
    public abstract class AbstractCommandService<TEntrada> : AbstractCommand
    {
        protected readonly IAbstractService<TEntrada> _service;

        public AbstractCommandService(IAbstractUnityOfWork uow)
        {
            _service = new AbstractService<TEntrada>(uow);
        }
    }
}